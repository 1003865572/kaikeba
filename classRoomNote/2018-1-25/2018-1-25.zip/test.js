const uuid=require('uuid/v4');

console.log(uuid().replace(/\-/g, ''));

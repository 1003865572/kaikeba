let b=new Buffer('abccc-=-dddder-=-qwerqwer');

console.log(b.slice(17).toString());

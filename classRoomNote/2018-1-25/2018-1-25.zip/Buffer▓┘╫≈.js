let b=new Buffer('abccc-=-dddder-=-qwerqwer');

console.log(b.indexOf('-=-'));

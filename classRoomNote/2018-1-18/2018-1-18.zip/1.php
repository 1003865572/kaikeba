<?php

echo $_GET['a']+$_GET['b'];

?>

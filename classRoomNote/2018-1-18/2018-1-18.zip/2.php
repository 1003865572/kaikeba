<?php

echo $_POST['a']+$_POST['b'];

?>

const url=require('url');

let obj=url.parse('https://www.baidu.com:8080/s?ie=utf-8&f=8&rsv_bp=0&rsv_idx=1&tn=baidu&wd=aa&rsv_pq=f80d982000063ffb&rsv_t=6498LAZdRZjq9v4v0hs88kZItnCjDpT6UNBKr%2FF83%2F%2Bg4eiPURW2eQl9Iwc&rqlang=cn&rsv_enter=1&rsv_sug2=0&inputT=10&rsv_sug4=10', true);

console.log(obj);

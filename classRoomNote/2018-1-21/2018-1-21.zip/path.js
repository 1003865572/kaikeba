const path=require('path');

let str='/var/local/www/aaa/1.png';

//dirname
//basename
//extname

console.log(path.extname(str));

<?php
var_dump($_FILES);
?>

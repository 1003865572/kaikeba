let a=12;
let [b,c]=[5,8];

const show=()=>{
  alert(a+b+c);
};

show();
